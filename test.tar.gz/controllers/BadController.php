<?php

class BadController 
{
    public function actionIndex() 
    {
        $pageTitle = 'Шо де хуйово';

        require_once ROOT.'/views/bad/index.php';

        return TRUE;
    }
    
    public function actionView($id) {
        
        
        return TRUE;
    }
}
