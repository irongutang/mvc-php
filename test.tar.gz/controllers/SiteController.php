<?php 

/**
* Main Controller of the site
*/
class SiteController {

	public function actionIndex($page = 1) {
    $hotList = array();
    $hotList = Hot::getHotList($page);
    $pageTitle = 'Основная';
    $sectionTitle = 'Деловые советы';

    $total = Hot::getHotCount();

    $pagination = new Pagination(array(
    	'itemsCount' => $total,
    	'itemsPerPage' => Hot::SHOW_BY_DEFAULT,
    	'currentPage' => $page,
    ));

		require_once(ROOT.'/views/site/index.php');
		return true;
	}

    public function actionContact() {

        $mail = 'jimm30g@gmail.com';
        $subject = 'Тема';
        $message = 'Содержимое';
        $result = mail($mail, $subject, $message);
        echo '<pre>';
        print_r($result);
        die;
    }
}