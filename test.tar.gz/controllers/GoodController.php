<?php

class GoodController 
{
    public function actionIndex() 
    {
        $pageTitle = 'Не хуйовые дела';

        require_once ROOT.'/views/good/index.php';

        return TRUE;
    }
    
    public function actionView($id) {
        
        
        return TRUE;
    }
}