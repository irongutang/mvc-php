<?php
class ProductController {
   
    public function actionList() {
        echo 'ProductController actionList';
        return TRUE;
    }

    public function actionView($id) {

    	require_once(ROOT.'/views/product/view.php');
    	return true;
    }
}
