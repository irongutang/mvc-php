<?php include ROOT.'/views/layouts/header.php'; ?>
<div class="container" style="height: 470px;">
	<section class="good">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="box">
					<h3><?php echo($pageTitle) ?></h3>
					
        </div>                        
			</div>
		</div>
	</section>
</div>		
<?php include ROOT.'/views/layouts/footer.php'; ?>