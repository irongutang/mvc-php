</div><!-- .wrap -->
<footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12 fbox">
                    <h4>IRON GUTANG</h4>
                    <p class="text">Иллюминаты - это те, чьи лица мы напоследок увидим в иллюминаторах той самой ракеты, которая всех пидорасов за раз, унесет на другую планету. На другую, а именно Марс (для начала)</p>
                    <ul class="list-inline">
                        <li><a href="https://vk.com/id74587265" target="_blank"><i class="fa fa-vk"></i></a></li>
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>                        
                    </ul>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12 fbox">
                    <h4>СЛУЖБА</h4>
                    <ul class="big">
                        <li><a href="#" title="">Title One</a></li>
                        <li><a href="#" title="">Title Two</a></li>
                        <li><a href="#" title="">Title Three</a></li>
                        <li><a href="#" title="">Title Four</a></li>
                        <li><a href="#" title="">Title Five</a></li>
                        <li><a href="#" title="">Title Six</a></li>
                        <li><a href="#" title="">Title Seven</a></li>
                        <li><a href="#" title="">Title Eight</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12 fbox">
                    <h4>КОНТЕНТ</h4>
                    <ul class="big">
                        <li><a href="#" title="">Title One</a></li>
                        <li><a href="#" title="">Title Two</a></li>
                        <li><a href="#" title="">Title Three</a></li>
                        <li><a href="#" title="">Title Four</a></li>
                        <li><a href="#" title="">Title Five</a></li>
                        <li><a href="#" title="">Title Six</a></li>
                        <li><a href="#" title="">Title Seven</a></li>
                        <li><a href="#" title="">Title Eight</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12 fbox">
                    <h4>КОНТАКТЫ</h4>
                    <p class="text">СССР, Киев</p>
                    <p><a href="tel:+380956687731"><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span> +38 095 668 77 31</a></p>
                    <p><a href="mailto:jimm30g@gmail.com"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> jimm30g@gmail.com</a></p>
                </div>
            </div>
        </div>
        <div id="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <p class="pull-left">&copy; 2016 - <?php echo(date('Y')) ?> IRON GUTANG</p>
                    </div>
                    <div class="col-md-8">
                        <ul class="list-inline navbar-right">
                            <li><a href="/">ОСНОВНАЯ</a></li>
                            <li><a href="/contact">ПИСЬМО ДИРЕКЦИИ</a></li>
                            <li><a href="#">MENU ITEM</a></li>
                            <li><a href="#">MENU ITEM</a></li>
                            <li><a href="#">MENU ITEM</a></li>
                            <li><a href="#">MENU ITEM</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>        
    </footer>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="/template/js/bootstrap.min.js"></script>
    <script src="/template/js/script.js"></script>
</body>
</html>