<section class="hero_area">
    <div class="hero_content">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <img src="/template/img/serp-i-molot.png">
                    <h1>Асимметричный ответ</h1>
                    <h4 class="slogan">красный торсионный коммунизм</h4>
                </div>
            </div>
        </div>
    </div>
</section>