<?php
return array(
    'host' => 'localhost',
    'dbname' => 'irongutang_db',
    'user' => 'root',
    'password' => '123',
);
